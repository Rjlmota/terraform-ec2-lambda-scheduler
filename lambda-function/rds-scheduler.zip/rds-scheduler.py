import botocore
import boto3
import logging
import json
import sys
from botocore.exceptions import ClientError


logger = logging.getLogger()
logger.setLevel(logging.INFO)
rds = boto3.client('rds')

""" 
    EventBridge sample event: { "action": "start", "clusterid": "rds-name" }
"""

def startRDS(clusterid):
    try:
        rds.start_db_cluster(DBClusterIdentifier=clusterid)
        logger.info('Success :: start_db_cluster ' + clusterid) 
    except ClientError as e:
        logger.error(e)   
    return "started:OK"

def stopRDS(clusterid):
    try:
        rds.stop_db_cluster(DBClusterIdentifier=clusterid)
        logger.info('Success :: stop_db_cluster ' + clusterid) 
    except ClientError as e:
        logger.error(e)   
    return "stopped:OK"


def lambda_handler(event, context):
    logger.info("Event: " + str(event))
    clusterid = event.get('clusterid')
    action = event.get('action')
    
    if action == 'start':
        startRDS(clusterid)
    elif action == 'stop':
        stopRDS(clusterid)
        
    return {
    	'statusCode': 200,
    	'body': json.dumps("Script execution completed. See Cloudwatch logs for complete output")
	}
